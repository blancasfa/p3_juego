const OPPONENT_HEIGHT = 5,
    OPPONENT_PICTURE = "assets/new_opponent_image.png",
    OPPONENT_PICTURE_DEAD = "assets/new_opponent_image_dead.png",
    OPPONENT_SPEED = 5,
    OPPONENT_WIDTH = 5,
    GAME_OVER_PICTURE = "assets/game_over.png",
    YOU_WIN_PICTURE = "assets/you_win.png",
    KEY_LEFT = "LEFT",
    KEY_RIGHT = "RIGHT",
    KEY_SHOOT = "SHOOT",
    MIN_TOUCHMOVE = 20,
    PLAYER_HEIGHT = 5,
    PLAYER_PICTURE = "assets/new_player_image.png",
    PLAYER_PICTURE_DEAD = "assets/new_player_image_dead.png",
    PLAYER_SPEED = 20,
    BOSS_HEIGHT= 5,
    BOSS_PICTURE = "assets/jefazo.png",// Ruta de la imagen del jefe vivo
    BOSS_PICTURE_DEAD = "assets/jefazo_muerto.png", // Ruta de la imagen del jefe muerto    
    BOSS_SPEED = 10,
    BOSS_WIDTH = 10,
    PLAYER_WIDTH = 5,
    SHOT_HEIGHT = 1.5,
    SHOT_SPEED = 20,
    SHOT_PICTURE_PLAYER = "assets/shot1.png",
    SHOT_PICTURE_OPPONENT = "assets/shot2.png",
    SHOT_WIDTH = 1.5;

function getRandomNumber (range) {
    return Math.floor(Math.random() * range);
}

function collision (div1, div2) {
    const a = div1.getBoundingClientRect(),
        b = div2.getBoundingClientRect();
    return !(a.bottom < b.top || a.top > b.bottom || a.right < b.left || a.left > b.right);

}
function startGame() {
    // Oculta el tutorial
    document.getElementById("tutorial").style.display = "none";

    // Comienza el juego llamando al método start() de la instancia de Game
    game.start();
}

var game;
document.addEventListener("DOMContentLoaded", () => {
    game = new Game();
    game.initializeGame(); // Inicializa el juego sin comenzar aún
});
