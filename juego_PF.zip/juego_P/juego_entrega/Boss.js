class Boss extends Opponent {
    constructor(game) {
        super(game);
        this.speed *= 2; // El jefe tiene el doble de velocidad
        this.myImage = BOSS_PICTURE; // Imagen del jefe vivo
        this.myImageDead = BOSS_PICTURE_DEAD; // Imagen del jefe muerto
        this.image.src = this.myImage; // Asegurarse de que la imagen viva se aplique al crearlo
    }

    // Disparo a intervalos específicos
    shoot() {
        if (!this.dead && !this.game.ended) {
            if (!this.game.paused) {
                this.game.shoot(this);
            }
            // Ajusta el intervalo entre disparos para que no sea constante
            setTimeout(() => this.shoot(), 500 + getRandomNumber(1500));
        }
    }
    collide() {
        if (!this.dead) {
            super.collide();
            this.dead = true; // Marcar al jefe como derrotado
            this.game.SCORE++; // Incrementa el puntaje al derrotar al jefe
            console.log("Jefe derrotado, SCORE incrementado a:", this.game.SCORE);
            // No llamamos a endGame aquí; el juego continuará hasta alcanzar SCORE >= 5
        }
    }
}

